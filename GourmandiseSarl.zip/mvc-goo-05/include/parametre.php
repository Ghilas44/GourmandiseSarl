<?php
// Definition de constantes pour l'accès à la base de données

define('SERVEUR', 'localhost');
define('BASE', 'gourmandisesarl');
define('NOM', 'root');
define('PASS', '');
